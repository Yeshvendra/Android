package com.example.testit;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Webmini extends Activity {

	WebView ourBrow;
	String url;
	@Override
	protected void onCreate(Bundle savedInstanceState) {		
		super.onCreate(savedInstanceState);
		/*ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		android.net.NetworkInfo wifi= cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		android.net.NetworkInfo datac= cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		if((wifi!=null&datac!=null)&&(wifi.isConnected()||datac.isConnected()))*/
		{
			//imageView.setVisibility(View.GONE);
			setContentView(R.layout.activity_webmini);
			ourBrow=(WebView)findViewById(R.id.wvBrowser);
			ourBrow.getSettings().setLoadWithOverviewMode(true);
			ourBrow.getSettings().setJavaScriptEnabled(true);
			ourBrow.setWebViewClient(new ourViewClient());
			SharedPreferences getprefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
			url=getprefs.getString("ip","192.168.173.1");
			try{
				ourBrow.loadUrl("http://"+url+":80/UKC/index.php");
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		/*else
		{
			Toast toast=Toast.makeText(Webmini.this, "Server Not Connected !!", Toast.LENGTH_LONG);
			toast.show();
		}*/
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		super.onCreateOptionsMenu(menu);
		MenuInflater blowUp=getMenuInflater();
		blowUp.inflate(R.menu.menu_down,menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch(item.getItemId()){
		case R.id.aboutus:
			Intent i=new Intent(this,AboutUs.class);
			startActivity(i);
			break;
		case R.id.preferences:
			Intent j=new Intent(this,prefs.class);
			startActivity(j);
			break;
		case R.id.exit:
			finish();
			break;
		case R.id.home:
			ourBrow.loadUrl("http://"+url+":80/UKC/index.php");
			break;
		}
	return false;
	}
}
