<?php
	
	include("session.php");
	include("exam_session.php");
?>

<?php
	
	$marks=0;
	
	$answer1="";$answer2="";$answer3="";$answer4="";$answer5="";
	$answer6="";$answer7="";$answer8="";$answer9="";$answer10="";
	$answer11="";$answer12="";$answer13="";$answer14="";$answer15="";
	if(isset($_POST["one"]))
	{
		$answer1=$_POST["one"];
		if($answer1=='a') $marks+=1;
	}
	if(isset($_POST["two"]))
	{
		$answer2= $_POST['two'];
		if($answer2=='a') $marks+=1;
	}
	if(isset($_POST["three"]))
	{
		$answer3= $_POST['three'];
		if($answer3=='a') $marks+=1;
	}
	if(isset($_POST["four"]))
	{
		$answer4=$_POST["four"];
		if($answer4=='a') $marks+=1;
	}
	if(isset($_POST["five"]))
	{
		$answer5=$_POST["five"];
		if($answer5=='a') $marks+=1;
	}
	if(isset($_POST["six"]))
	{
		$answer6=$_POST["six"];
		if($answer6=='a') $marks+=1;
	}
	if(isset($_POST["seven"]))
	{
		$answer7=$_POST["seven"];
		if($answer7=='a') $marks+=1;
	}
	if(isset($_POST["eight"]))
	{
		$answer8=$_POST["eight"];
		if($answer8=='a') $marks+=1;
	}
	if(isset($_POST["nine"]))
	{
		$answer9=$_POST["nine"];
		if($answer9=='a') $marks+=1;
	}
	if(isset($_POST["ten"]))
	{
		$answer10=$_POST["ten"];
		if($answer10=='a') $marks+=1;
	}
	if(isset($_POST["eleven"]))
	{
		$answer11=$_POST["eleven"];
		if($answer11=='a') $marks+=1;
	}
	if(isset($_POST["twelve"]))
	{
		$answer12=$_POST["twelve"];
		if($answer12=='a') $marks+=1;
	}
	if(isset($_POST["thirteen"]))
	{
		$answer13=$_POST["thirteen"];
		if($answer13=='a') $marks+=1;
	}
	if(isset($_POST["fourteen"]))
	{
		$answer14=$_POST["fourteen"];
		if($answer14=='a') $marks+=1;
	}
	if(isset($_POST["fifteen"]))
	{
		$answer15=$_POST["fifteen"];
		if($answer15=='a') $marks+=1;
	}
	if($marks>0)
	{
		
		$_SESSION["total_marks"] = $marks;
		echo '<br /><br /> Marks obtained : '.$marks;
		header("location: last_ans.php");
		
	}
?>

<?php

	if(isset($_GET['question']))
	{
		$question = preg_replace('/[^0-9]/', "", $_GET['question']);
		$next = $question + 1;
		$prev = $question - 1;
		if(!isset($_SESSION['qid_array']) && $question != 1)
		{
			$msg = "Sorry! No cheating.";
			header("location: index.php?msg=$msg");
			exit();
		}
		if(isset($_SESSION['qid_array']) && in_array($question, $_SESSION['qid_array']))
		{
			$msg = "Sorry, Cheating is not allowed. You will now have to start over. Haha.";
			unset($_SESSION['answer_array']);
			unset($_SESSION['qid_array']);
			session_destroy();
			header("location: index.php?msg=$msg");
			exit();
		}
		if(isset($_SESSION['lastQuestion']) && $_SESSION['lastQuestion'] != $prev)
		{
			$msg = "Sorry, Cheating is not allowed. You will now have to start over. Haha.";
			unset($_SESSION['answer_array']);
			unset($_SESSION['qid_array']);
			session_destroy();
			header("location: index.php?msg=$msg");
			exit();
		}
	}
?>

<!doctype html>
<html>
	<head>
		<!--<script type="text/javascript" src="./img/aplha.js">
		
		</script>
		<script>
			$(function() {
			$( "#Awesome_Radio_Button" ).buttonset();
			);
		</script>-->

		<meta charset="utf-8">
		<title>
			Quiz Page
		</title>
		<script type="text/javascript">
			function countDown(secs,elem)
			{
				var element = document.getElementById(elem);
				element.innerHTML = "You have "+secs+" seconds remaining.";
				if(secs < 1)
				{
					var xhr = new XMLHttpRequest();
					var url = "userAnswers.php";
					var vars = "radio=0"+"&qid="+<?php echo $question; ?>;
					xhr.open("POST", url, true);
					xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
					xhr.onreadystatechange = function()
					{
						if(xhr.readyState == 4 && xhr.status == 200)
						{
							alert("You did not answer the question in the allotted time. It will be marked as incorrect.");
							clearTimeout(timer);
						}
					}
					xhr.send(vars);
					document.getElementById('counter_status').innerHTML = "";
					document.getElementById('btnSpan').innerHTML = '<h2>Times Up!</h2>';
					document.getElementById('btnSpan').innerHTML += '<a href="quiz.php?question=<?php echo $next; ?>">Click here now</a>';
		
				}
				secs--;
				var timer = setTimeout('countDown('+secs+',"'+elem+'")',1000);
			}
		</script>
		
		<script>
			function getQuestion()  //AJAX function to refresh div
			{
				var hr = new XMLHttpRequest();
				hr.onreadystatechange = function()
				{
					if (hr.readyState==4 && hr.status==200)
					{
						var response = hr.responseText.split("|");	//.split takes string and whereever pipes are present it repalces that and converts it into string
						if(response[0] == "finished")
						{
							document.getElementById('status').innerHTML = response[1];
						}
						var nums = hr.responseText.split(",");
						document.getElementById('question').innerHTML = nums[0];
						document.getElementById('answers').innerHTML = nums[1];
						document.getElementById('answers').innerHTML += nums[2];
					}
				}
				hr.open("GET", "questions.php?question=" + <?php //echo $question; ?>, true);
				hr.send();
			}
			function x()
			{
				var rads = document.getElementsByName("rads");
				for ( var i = 0; i < rads.length; i++ )
				{
					if ( rads[i].checked )
					{
						var val = rads[i].value;
						return val;
					}
				}
			}
			function post_answer()
			{
				var p = new XMLHttpRequest();
				var id = document.getElementById('qid').value;
				var url = "userAnswers.php";
				var vars = "qid="+id+"&radio="+x();
				p.open("POST", url, true);
				p.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				p.onreadystatechange = function()
				{
					if(p.readyState == 4 && p.status == 200)
					{
						document.getElementById("status").innerHTML = '';
						alert("Thanks, Your answer was submitted"+ p.responseText);
						var url = 'quiz.php?question=<?php //echo $next; ?>';
						window.location = url;
					}
				}
				p.send(vars);
				document.getElementById("status").innerHTML = "processing...";
	
			}
		</script>
		
		<script>
			window.oncontextmenu = function()
			{
				return false;
			}
		</script>

		<style type="text/css">
			*
			{
				margin:0;
			}

			#out
			{
				//margin:0;
				//padding:2%;
				//border:solid black;
				background-image:url(./img/g8.jpg);
				//background-color:black;
				height: 100%;
				width: 100%;
				overflow: scroll;
			}

			#in
			{
				//border:solid black;
				//overflow: scroll;
				width:100%;
				//margin:0;
				height:100%;
				//margin-left:auto;
				//margin-right:auto;
				//margin-top:-49%;
				//background-color:white;
				background-image:url(./img/g8.jpg);
				//border-radius:25%;
			}	

			#my{
				//background-color: #d0d0d0;
				background-image:url(./img/hara.jpg);
				width: 80%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 25px;
				box-shadow:inset 0px 0px 15px 3px #707070;
			}		

			#mya{
				background-color: #0d1;
				color: #000;
				background-image:url(./img/hara.jpg);
				width: 80%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 10px;
				box-shadow:inset 0px 0px 15px 3px #707070;
			}


			#head{
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				width: 98%;
				margin-left: 0%;
				margin-right: 0%
				//background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				//-moz-border-radius:17px;
				//-webkit-border-radius:17px;
				//border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				//cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				//padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;
				//margin-left: auto;
				//margin-right: auto;


			}


			.takequiz {
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				-moz-border-radius:17px;
				-webkit-border-radius:17px;
				border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;

			}
				.takequiz:hover {
					background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #8cbf70), color-stop(1, #2a6139));
					background:-moz-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-webkit-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-o-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-ms-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:linear-gradient(to bottom, #8cbf70 5%, #2a6139 100%);
					filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#8cbf70', endColorstr='#2a6139',GradientType=0);
					background-color:#8cbf70;
				}
				.takequiz:active {
					position:relative;
					top:1px;
				}

		</style>
	</head>

	<body id="out">
		<!--<div id="out" align="center">-->
			<div id="in" align="center" onLoad="getQuestion()">	

				<div id="head">
								
								<h4 align="center"><font face="courier" size="7	">TEST IT</font></h4>
								<!--<h2 align="center"> Universal Knowledge Center presents<br> TEST IT</h2>
								<h4 align="center"><p align="right">powered by BITW</p></h4>-->
				</div>

				<br /><br /><br />


				<div id="mya" align="center">

					<br />

					<div id="status">
						
						<font face="tahoma" size="4">	
							<?php
								echo "Hello ".$username;
								echo "<br /> Quiz Code : ".$code;
								echo '<br /> No. Of Questions : '.$no_qstns;
							?>
							
						</font>
						<div id="counter_status"></div>	
						

						<!--
						<div id="question"></div>	 
						<div id="answers"></div>-->
						
					</div>

					<?php
						echo '<br />';
						echo " Click Here To ... <a href='logout.php'> LogOut!</a>";
						
						
					?>
					<br /><br />
				</div>
				<script type="text/javascript">countDown(100,"counter_status");</script>
				<br />

				<div id="my">
					<form action="test.php" method="POST" align="left">
						<?php
							$maid=0;
							$matf=0;
							$zids=0;
							$macount=0;
							$questn_counter=0;
							$query=mysql_query("SELECT COUNT(*) FROM questions");
							$query5=mysql_query("SELECT COUNT(*) FROM answers");
							$row=mysql_fetch_array($query);
							$rows=$row[0];
							
							$row5=mysql_fetch_array($query5);
							$rows5=$row5[0];
						
							$query1=mysql_query("select question_id,question,type,code from questions");
							$query6=mysql_query("select id,question_id,answer,correct from answers");
							
							for($i=0; $i<$rows ; $i++)
							{
								$ans=mysql_fetch_array($query1);
								$name=$ans['code'];
								if($name == $code)
								{
									$msg=$ans['question'];
									echo '<div id="msg_pst"><br /> -------------------------------<br />
												  <br /><p class="msps"> '.$msg.' </p><br />
											</div>';
									$types=$ans['type'];
									$quest1=$ans['question_id'];
									
									for($k=0;$k<$rows5;$k++)
									{
										$ans5=mysql_fetch_array($query6);
										$quest2=$ans5['question_id'];
										if($quest1==$quest2)
										{
											if($questn_counter==0)
											{	
											
											
											if($types=="mc")
											{
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													
													echo '<input type="radio" name="one" value=a >';
													echo $msg5;
													echo '<br />';

													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
												
													echo ' <input type="radio" name="one" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
												//echo "string";
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="one" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$questn_counter+=1;
														$matf=0;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="one" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$questn_counter+=1;
														$matf=0;
														break;
													}

												}
											}
											//echo "string";
											
											}

											
											else if($questn_counter==1)
											{	
											
											//echo "I am Inside";
											if($types=="mc")
											{
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="two" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="two" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="two" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="two" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											
											else if($questn_counter==2)
											{	
											
											
											if($types=="mc")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="three" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="three" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="three" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="three" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											
											else if($questn_counter==3)
											{	
											
											
											if($types=="mc")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="four" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="four" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="four" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="four" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											
											else if($questn_counter==4)
											{	
											
											
											if($types=="mc")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="five" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="five" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="five" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="five" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											
											else if($questn_counter==5)
											{	
											
											
											if($types=="mc")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="six" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="six" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="six" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="six" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											
											else if($questn_counter==6)
											{	
											
											
											if($types=="mc")
											{
											
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="seven" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="seven" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="seven" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="seven" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											else if($questn_counter==7)
											{	
											
											
											if($types=="mc")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="eight" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="eight" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="eight" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="eight" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											else if($questn_counter==8)
											{	
											
											
											if($types=="mc")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="nine" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="nine" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="nine" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="nine" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											else if($questn_counter==9)
											{	
											
											
											if($types=="mc")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="ten" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="ten" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="ten" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="ten" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											else if($questn_counter==10)
											{	
											
											
											if($types=="mc")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="eleven" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="eleven" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="eleven" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="eleven" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											else if($questn_counter==11)
											{	
											
											
											if($types=="mc")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="twelve" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="twelve" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="twelve" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="twelve" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											else if($questn_counter==12)
											{	
											
											
											if($types=="mc")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="thirteen" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="thirteen" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="thirteen" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="thirteen" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											else if($questn_counter==13)
											{	
											
											
											if($types=="mc")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="fourteen" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="fourteen" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="fourteen" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="fourteen" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
											
											else if($questn_counter==14)
											{	
											
											
											if($types=="mc")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
													echo '<input type="radio" name="fifteen" value=a > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo ' <input type="radio" name="fifteen" value=False > '.$msg5.'<br />';
													$macount+=1;
													if($macount%4==0)
													{
														$questn_counter+=1;
														break;
													}

												}
											}
											else if($types=="tf")
											{
											
												$msg5=$ans5['answer'];
												$correct=$ans5['correct'];
												if($correct==1)
												{
												
													echo '<input type="radio" name="fifteen" value=a >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}
												}
												else if($correct!=1)
												{
												
													echo '<input type="radio" name="fifteen" value=False >'.$msg5.'<br />';
													$matf+=1;
													if($matf%2==0)
													{
														$matf=0;
														$questn_counter+=1;
														break;
													}

												}
											}
											
											}
										}	
									}
								}
							}
						?>
						<br />
						------------------------------<br /><br />
						<div align="center"><input type="submit" name="sub" class="takequiz" value="Submit Quiz" /></div>
						<br />
					</form>

				</div>
				<br />
			</div>
		<!--</div>-->
	</body>
</html>