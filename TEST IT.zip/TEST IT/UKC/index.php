<?php
	include("session.php");
?>

<?php
	if(isset($_POST["uname"]) && isset($_POST["paswd"]))
	{
		//echo "name:".$_POST['uname'];
		//echo "  password:".$_POST['paswd'];
		//echo "  Invalid Username Or Password, Please Try Again...";
		echo '<div id="msg_pst">
						  <p class="msps"> <h1 align="center"><font face="courier" size="3" color="red">Invalid Username or Password, Please Try Correcting it...</font></h1></p>
				</div>';
		//$user_login = preg_replace('#[^A-Za-z0-9]#i', '', $_POST["uname"]); // decrypt using md5 to filter 
		//$password_login = preg_replace('#[^A-Za-z0-9]#i', '', $_POST["paswd"]); //	" "
		//$password_login_md5 = md5($password_login);
		$sql = mysql_query("SELECT id FROM users WHERE username='".$_POST['uname']."' AND password='".$_POST['paswd']."'",$conn); //

		$userCount = mysql_num_rows($sql); //
		if ($userCount == 1)
		{
			if($row = mysql_fetch_array($sql))
			{ 
				$id = $row["id"];
			}
			$_SESSION["uname"] = $_POST['uname'];
			echo $_SESSION['uname'];
			header("location: home.php");
			exit();
		}
		else
		{
			//echo "name:".$_POST['uname'];
			//echo "password:".$_POST['paswd'];
			//echo 'Invalid Username Or Password, Please Try Again...';
			$sql = mysql_query("SELECT id FROM admin WHERE username='".$_POST['uname']."' AND password='".$_POST['paswd']."'",$conn); //

			$userCount = mysql_num_rows($sql); //
			if ($userCount == 1)
			{
				if($row = mysql_fetch_array($sql))
				{ 
					$id = $row["id"];
				}
				$_SESSION["admin"] = $_POST['uname'];
				echo $_SESSION['admin'];
				header("location: admin_home.php");
				//echo 'Invalid Username Or Password, Please Try Again...';
				exit();
			}
		}
	}
?>

<html>
	<head>
		<style type="text/css">
			*
			{
				margin:0;
			}
			/*
			#signin
			{
				border:solid black;
				width:98%;
				height:93.5%;
				margin-left:auto;
				margin-right:auto;
				background-color:white;
				background-image:url(./img/index.jpg);
				border-radius:25%;
			}
			input[type="text"]
			{
				height:8%;
				width:80%;
				margin-left:10%;
				//margin-right:auto;
				margin-top:3%;
				
				padding: 10px;
				border: solid 1px #fff;
				box-shadow: inset 5px 5px 7px 0 #707070;
				transition: box-shadow 0.3s;
			}
			#outer
			{
				margin:0;
				padding:2%;
				border:solid black;
				background-color:black;
			}
			input[type="submit"]
			{
				height:10%;
				width:50%;
				margin-left:25%;
				
				color: #fff;
				background-color: #6496c8;
				border: none;
				border-radius: 15px;
				box-shadow: 0 10px #27496d;
			}

			#header
			{
				width:100%;
				height:15%;
				//background-color:grey;
				color:white;
			}
			#signup
			{
				width:100%;
				height:18%;
				color:white;
				//background-color:#505050;
			}
			#abc
			{
				margin-top:-9%;
			}

			#out
			{
				width:100%;
				height:100%;
				background-image:url(./img/fl.jpg);
			}
			#in
			{
				width:100%;
				height:100%;
				//margin-left:auto;
				//margin-right:auto;
				background-image:url(./img/fl.jpg);
			}*/

			#out
			{
				width: 100%;
				height: 100%;
				background-image:url(./img/g8.jpg);
			}

			#in
			{
				//border:solid black;
				width:100%;
				height:100%;
				background-image:url(./img/g8.jpg);
			}

			#my{
				background-image:url(./img/hara.jpg);
				width: 80%;
				margin-top: auto;
				margin-bottom: auto;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 25px;
				box-shadow:inset 0px 0px 15px 3px #707070;
			}
			
			input[type="text"]
			{
				height:8%;
				width:80%;
				margin-left:10%;
				//margin-right:auto;
				margin-top:3%;				
				padding: 10px;
				border: solid 1px #fff;
				box-shadow: inset 5px 5px 7px 0 #707070;
				transition: box-shadow 0.3s;
			}

			input[type="password"]
			{
				height:8%;
				width:80%;
				margin-left:10%;
				//margin-right:auto;
				margin-top:3%;
				
				padding: 10px;
				border: solid 1px #fff;
				box-shadow: inset 5px 5px 7px 0 #707070;
				transition: box-shadow 0.3s;
			}

			input[type="submit"]
			{
				height:10%;
				width:50%;
				margin-left:25%;
				
				color: #fff;
				background-color: #0f0f0f;
				border: none;
				border-radius: 5px;
				//box-shadow: 0 10px #95a484;
			}
			
			#head
			{
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				width: 98%;
				margin-left: 1%;
				//margin-left: 0%;
				//margin-right: 0%
				//background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				//-moz-border-radius:17px;
				//-webkit-border-radius:17px;
				//border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				//cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				//padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;
				//margin-left: auto;
				//margin-right: auto;


			}
			/*
			#head
			{
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				padding-left: 1%;
				width: 100%;
				margin-left: auto;
				margin-right: auto;
				//background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				//-moz-border-radius:17px;
				//-webkit-border-radius:17px;
				//border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				//cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				//padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;
			}*/

			.myButton 
			{
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				-moz-border-radius:17px;
				-webkit-border-radius:17px;
				border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;

			}
				.myButton:hover 
				{
					background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #8cbf70), color-stop(1, #2a6139));
					background:-moz-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-webkit-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-o-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-ms-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:linear-gradient(to bottom, #8cbf70 5%, #2a6139 100%);
					filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#8cbf70', endColorstr='#2a6139',GradientType=0);
					background-color:#8cbf70;
				}
				.myButton:active 
				{
					position:relative;
					top:1px;
				}

		</style>
	</head>

	<body>
	<!--
	<div id="outer">
		<div id="signin">
		
			<div id="header">
				<h3>Get Ready for a QUick quIZ</h3><br />
				<h1>with BITW !</h1>
			</div>
			
			<div id=signup>
				<h2>Not A Member Yet!</h2>
				
			</div>
			
			<div id="abc">
				<input type="submit" name="sub" value="SIGN UP" />
			</div>
			<br /><br />
			<div id=bc>
				<form action="index.php" method="POST">
					<input type="text" name="uname" placeholder="USERNAME" /><br /><br /><br />
					<input type="text" name="paswd" placeholder="PASSWORD" /><br /><br /><br />
					<input type="submit" name="sub" value="Log In" />
				</form>
			</div>
		</div>
	</div>-->
		<div id="out">

			<div id="in">

				<div id="head">
					
					<h4 align="center"><font face="courier" size="7">TEST IT</font></h4>
					<!--<h2 align="center"> Universal Knowledge Center presents<br> TEST IT</h2>
					<h4 align="center"><p align="right">powered by BITW</p></h4>-->
					
				</div>

				<br/><br/><br/><br/><br/>
				

				<br/><br/><br/><br/>

				<div id="my">

				<br/>
					
					<form action="index.php" method="POST">
						<input type="text" name="uname" placeholder="USERNAME" /><br /><br />
						<input type="password" name="paswd" placeholder="PASSWORD" /><br /><br />
						<input type="submit" class="myButton" name="sub" value="Log In" />
					</form>
				
					<br />

						<div align="center" id="signup">
						<?php 
							//echo " Not a member yet! Click here to <a href='signup.php'> SignUp </a>";
						?>
						</div>
						<br/>

				</div>

				<br /><br /><br />

				
			
			</div>

		</div>

	</body>
</html>