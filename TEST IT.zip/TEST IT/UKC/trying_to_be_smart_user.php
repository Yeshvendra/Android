<?php
	echo "Don't try to be oversmart !! You have been caught cheating !!";
?>
echo '<div id="msg_pst">
						  <p class="msps"> <h1 align="center"><font face="courier" size="3" color="red">Dont try to be oversmart !! You have been caught cheating !!</font></h1></p>
				</div>';