<?php
	
	include("session.php");
	include("exam_session.php");
?>

<html>
<head>
	<style type="text/css">
			*
			{
				margin:0;
			}


			#out
			{
				//margin:0;
				//padding:2%;
				//border:solid black;
				background-image:url(./img/g8.jpg);
				//background-color:black;
			}

			#in
			{
				//border:solid black;
				width:99%;
				//margin:0;
				height:100%;
				margin-left:auto;
				margin-right:auto;
				//margin-top:-49%;
				background-color:white;
				background-image:url(./img/g8.jpg);
				//border-radius:25%;
			}	

			#my{
				//background-color: #d0d0d0;
				background-image:url(./img/hara.jpg);
				width: 85%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 25px;
				box-shadow:inset 0px 0px 15px 3px #707070;
			}		

			#mya{
				//background-color: #d0d0d0;
				background-image:url(./img/hara.jpg);
				width: 40%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 10px;
				box-shadow:inset 0px 0px 15px 3px #707070;
			}


			#head{
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				width: 100%;
				margin-left: 0%;
				margin-right: 0%
				//background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				//-moz-border-radius:17px;
				//-webkit-border-radius:17px;
				//border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				//cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				//padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;
				//margin-left: auto;
				//margin-right: auto;


			}
	</style>	
</head>
	<body>
		<div id="out">
			<div id="in">	

				<div id="head">
					<h4 align="center"><font face="courier" size="7	">TEST IT</font></h4>
					<!--<h2 align="center"> Universal Knowledge Center presents<br> TEST IT</h2>
					<h4 align="center"><p align="right">powered by BITW</p></h4>-->
				</div>

				<br /><br /><br /><br />

				<div align="center" id="mya">
					<font size="4" face="tamoha">
						<?php
							echo "Hello ".$username;
						?>
					</font>
				</div>
					
				
				<br /><br /><br />
				<br /><br />
					
				<div id="my">

					<br />
					
					
					<div align="center">
						<font face="tamoha" size="4"><b>
							<u>Result Page</u><br /><br />
							<?php
								echo " Quiz Code : ".$code;
							?>
						</b></font>
					</div>
					<div align="center">
						<?php

							$result=($total_marks/$no_qstns)*100;
							$d=date("Y-m-d");
							$query=mysql_query("INSERT INTO quiz_takers VALUES ('','$username','$total_marks','$result','$d','$code')",$conn);
							echo "<br />";
							echo "Your score(Marks/Total) :- "
						?>
						<br /><br />
						<div><font size="5" color=RED><b>
						<?php	echo $total_marks;
							echo " / ";
							echo $no_qstns;
						?>
						</b></font></div>
						<?php
							echo "<br />";
							echo "Your Percentage = ";
							echo $result;
							echo " %";
						?>
					</div>

					<br /><br />

					<div align="center">
						<?php
							echo " Click Here To ....  <a href='logout.php'> Log Out!</a>";
						?>
					</div>

					<br />
				</div>
			</div>
		</div>
	</body>
</html>

