<?php 
	include("connect_to_db.php");
	$abc="i am BITW";
	session_start();
	if (!isset($_SESSION['admin']))
	{
		//echo "not set";
		$admin="";
	}
	else
	{
		//echo 'in head_index'.$_SESSION['uname'];
		$admin = $_SESSION['admin'];
		//include 'head_menu.php';
		$adm_na="";
		
	}
	
	if (!isset($_SESSION['aname']))
	{
		//echo "not set";
		$adm_na="";
	}
	else
	{
		//echo 'in head_index'.$_SESSION['uname'];
		$adm_na = $_SESSION['aname'];
		//include 'head_menu.php';
	
	}
	
?>