<?php 
	include("connect_to_db.php");
	$abc="i am BITW";
	//session_start();
	if (!isset($_SESSION['code']))
	{
		//echo "not set";
		$code="";
	}
	else
	{
		//echo 'in head_index'.$_SESSION['uname'];
		$code = $_SESSION['code'];
		//include 'head_menu.php';
		$no_qstns="";
		
	}
	
	
	
	if (!isset($_SESSION['no_of_qstns']))
	{
		//echo "not set";
		$no_qstns="";
	}
	else
	{
		//echo 'in head_index'.$_SESSION['uname'];
		$no_qstns = $_SESSION['no_of_qstns'];
		//include 'head_menu.php';
	
	}
	
	if (!isset($_SESSION['total_marks']))
	{
		//echo "not set";
		$total_marks="";
	}
	else
	{
		//echo 'in head_index'.$_SESSION['uname'];
		$total_marks = $_SESSION['total_marks'];
		//include 'head_menu.php';
	
	}
	
?>