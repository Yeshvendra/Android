<?php
	include("session.php");
?>




<?php
	if(isset($_POST['desc']))
	{
		if(!isset($_POST['iscorrect']) || $_POST['iscorrect'] == "")
		{
			echo '<div id="msg_pst">
						  <p class="msps"> <h1 align="center"><font face="courier" size="3" color="red">Sorry, important data to submit your question is missing. Please try again and make sure you select a correct answer for the question.</font></h1></p>
				</div>';
			//echo "Sorry, important data to submit your question is missing. Please press back in your browser and try again and make sure you select a correct answer for the question.";
			//exit();
		}
		if(!isset($_POST['type']) || $_POST['type'] == "")
		{
			echo '<div id="msg_pst">
						  <p class="msps"> <h1 align="center"><font face="courier" size="3" color="red">Sorry, there was an error parsing the form. Please try again.</font></h1></p>
				</div>';
			//echo "Sorry, there was an error parsing the form. Please press back in your browser and try again";
			//exit();
		}
		$question = $_POST['desc'];
		$answer1 = $_POST['answer1'];
		$answer2 = $_POST['answer2'];
		$answer3 = $_POST['answer3'];
		$answer4 = $_POST['answer4'];
		$type = $_POST['type'];
		$code = $_POST['code'];
		$type = preg_replace('/[^a-z]/', "", $type);
		$isCorrect = preg_replace('/[^0-9a-z]/', "", $_POST['iscorrect']);
		$answer1 = strip_tags($answer1);
		$answer1 = mysql_real_escape_string($answer1);
		$answer2 = strip_tags($answer2);
		$answer2 = mysql_real_escape_string($answer2);
		$answer3 = strip_tags($answer3);
		$answer3 = mysql_real_escape_string($answer3);
		$answer4 = strip_tags($answer4);
		$answer4 = mysql_real_escape_string($answer4);
		$question = strip_tags($question);
		$question = mysql_real_escape_string($question);
		if($type == 'tf')
		{
			if((!$question) || (!$answer1) || (!$answer2) || (!$isCorrect))
			{
				echo '<div id="msg_pst">
						  <p class="msps"> <h1 align="center"><font face="courier" size="3" color="red">Sorry, All fields must be filled in to add a new question to the quiz. Please try again.</font></h1></p>
				</div>';
				//echo "Sorry, All fields must be filled in to add a new question to the quiz. Please press back in your browser and try again.";
				//exit();
			}
		}
		if($type == 'mc')
		{
			if((!$question) || (!$answer1) || (!$answer2) || (!$answer3) || (!$answer4) || (!$isCorrect))
			{
				echo '<div id="msg_pst">
						  <p class="msps"> <h1 align="center"><font face="courier" size="3" color="red">Sorry, All fields must be filled in to add a new question to the quiz. Please try again.</font></h1></p>
				</div>';
				//echo "Sorry, All fields must be filled in to add a new question to the quiz. Please press back in your browser and try again.";
				//exit();
			}
		}
		$sql = mysql_query("INSERT INTO questions (question, type,code,username) VALUES ('$question', '$type', '$code', '$username')")or die(mysql_error());
		$lastId = mysql_insert_id();
		mysql_query("UPDATE questions SET question_id='$lastId' WHERE id='$lastId' LIMIT 1")or die(mysql_error());
		//// Update answers based on which is correct //////////
		if($type == 'tf')
		{
			if($isCorrect == "answer1")
			{
				$sql2 = mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer1', '1')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer2', '0')")or die(mysql_error());
				$msg = 'Thanks, your question has been added';
				$answer3="";
				header('location: quest.php?msg='.$msg.'');
				exit();
			}
			if($isCorrect == "answer2")
			{
				$sql2 = mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer1', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer2', '1')")or die(mysql_error());
				$msg = 'Thanks, your question has been added';
				header('location: quest.php?msg='.$msg.'');
				exit();
			}	
		}
		if($type == 'mc')
		{
			if($isCorrect == "answer1")
			{
				$sql2 = mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer1', '1')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer2', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer3', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer4', '0')")or die(mysql_error());
				$msg = 'Thanks, your question has been added';
				header('location: quest.php?msg='.$msg.'');
				exit();
			}
			if($isCorrect == "answer2")
			{
				$sql2 = mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer1', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer2', '1')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer3', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer4', '0')")or die(mysql_error());
				$msg = 'Thanks, your question has been added';
				header('location: quest.php?msg='.$msg.'');
				exit();
			}
			if($isCorrect == "answer3")
			{
				$sql2 = mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer1', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer2', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer3', '1')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer4', '0')")or die(mysql_error());
				$msg = 'Thanks, your question has been added';
				header('location: quest.php?msg='.$msg.'');
				exit();
			}
			if($isCorrect == "answer4")
			{
				$sql2 = mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer1', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer2', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer3', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer4', '1')")or die(mysql_error());
				$msg = 'Thanks, your question has been added';
				header('location: quest.php?msg='.$msg.'');
				exit();
			}
		}
	}
?>

<?php 
	$msg = "";
	if(isset($_GET['msg']))
	{
		$msg = $_GET['msg'];
	}
?>
<?php 
	if(isset($_POST['reset']) && $_POST['reset'] != "")
	{
		$reset = preg_replace('/^[a-z]/', "", $_POST['reset']);
		mysql_query("TRUNCATE TABLE questions")or die(mysql_error());
		mysql_query("TRUNCATE TABLE answers")or die(mysql_error());
		$sql1 = mysql_query("SELECT id FROM questions LIMIT 1")or die(mysql_error());
		$sql2 = mysql_query("SELECT id FROM answers LIMIT 1")or die(mysql_error());
		$numQuestions = mysql_num_rows($sql1);
		$numAnswers = mysql_num_rows($sql2);
		if($numQuestions > 0 || $numAnswers > 0)
		{
			echo "Sorry, there was a problem reseting the quiz. Please try again later.";
			exit();
		}
		else
		{
			echo "Thanks! The quiz has now been reset back to 0 questions.";
			exit();
		}
	}
	
	//reading N
	
	//$number=@$_POST['number'];
	if(isset($_POST["number"] ))
	{
		$numb=@$_POST['noq'];
		//echo "number=".$numb;
	}
	
?>

<html>
	<head>
		<script>
			function showDiv(el1,el2)
			{
				document.getElementById(el1).style.display = 'block';
				document.getElementById(el2).style.display = 'none';
			}
		</script>
		
		<script>
		function resetQuiz()
		{
			var x = new XMLHttpRequest();
			var url = "addQuestions.php";
			var vars = 'reset=yes';
			x.open("POST", url, true);
			x.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			x.onreadystatechange = function()
			{
				if(x.readyState == 4 && x.status == 200)
				{
					document.getElementById("resetBtn").innerHTML = x.responseText;
				}
			}
			x.send(vars);
			document.getElementById("resetBtn").innerHTML = "processing...";
	
		}
		</script>
		
		<style type="text/css">
			.content
			{
				margin-top:48px;
				margin-left:auto;
				margin-right:auto;
				width:90%;
				border:#333 1px solid;
				border-radius:12px;
				-moz-border-radius:12px;
				padding:12px;
				display:none;
			}
			*
			{
				margin:0;
			}
			/*
			#in
			{
				//border:solid black;
				width:95%;
				//margin:0;
				height:80%;
				margin-left:auto;
				margin-right:auto;
				margin-top:2%;
				background-color:white;
				background-image:url(./img/download.jpg);
				//border-radius:25%;
			}
			*/

			#out
			{
				//margin:0;
				//padding:2%;
				//border:solid black;
				background-image:url(./img/g8.jpg);
				//background-color:black;
			}

			#in
			{
				//border:solid black;
				width:98%;
				//margin:0;
				height:100%;
				margin-left:auto;
				margin-right:auto;
				//margin-top:-49%;
				background-color:white;
				background-image:url(./img/g8.jpg);
				//border-radius:25%;
			}

			button[type="button"]
			{
				height:10%;
				width:70%;
				//margin-left:auto;
				font-size:96%;
				color: #fff;
				background-color: #000000;
				border: none;
				border-radius: 10px;
				//box-shadow: 0 10px #95a484;
			}

			/*
			#outer
			{
				margin:0;
				padding:1%;
				background-image:url(./img/blue.jpg);
				height:295%;
				//width:94%;
				
				//border:solid black;
				margin-top:-5.5%
				
			}
			#inner
			{
				//border:solid black;
				width:90%;
				margin-top:0px;
				color:white;
				font-size:30px
			}
			*/
			
			input[type='text']
			{
				width: 200px;
				height: 29px;
				border-radius: 3px;
				border: 1px solid #CCC;
				padding: 8px;
				font-weight: 200;
				font-size: 15px;
				font-family: Verdana;
				box-shadow: 1px 1px 5px #CCC;
			}
			
			/***FIRST STYLE THE BUTTON***/
			input#submitbutton
			{
				border:2px groove #7c93ba;
				cursor:pointer; /*forces the cursor to change to a hand when the button is hovered*/
				padding: 5px 25px;
				
				/*give the background a gradient - see cssdemos.tupence.co.uk/gradients.htm for more info*/
				background-color:#6b6dbb; /*required for browsers that don't support gradients*/
				background: -webkit-gradient(linear, left top, left bottom, from(#88add7), to(#6b6dbb));
				background: -webkit-linear-gradient(top, #88add7, #6b6dbb);
				background: -moz-linear-gradient(top, #88add7, #6b6dbb);
				background: -o-linear-gradient(top, #88add7, #6b6dbb);
				background: linear-gradient(top, #88add7, #6b6dbb);
				
				/*style to the text inside the button*/
				font-family:Andika, Arial, sans-serif; /*Andkia is available at http://www.google.com/webfonts/specimen/Andika*/
				color:#fff;
				font-size:1.1em;
				letter-spacing:.1em;
				font-variant:small-caps;
				
				/*give the corners a small curve*/
				-webkit-border-radius: 0 15px 15px 0;
				-moz-border-radius: 0 15px 15px 0;
				border-radius: 0 15px 15px 0;
				
				/*add a drop shadow to the button*/
				-webkit-box-shadow: rgba(0, 0, 0, .75) 0 2px 6px;
				-moz-box-shadow: rgba(0, 0, 0, .75) 0 2px 6px;
				box-shadow: rgba(0, 0, 0, .75) 0 2px 6px;
			}
			/***NOW STYLE THE BUTTON'S HOVER AND FOCUS STATES***/
			input#submitbutton:hover, input#submitbutton:focus
			{
				color:#edebda;
				/*reduce the spread of the shadow to give a pushed effect*/
				-webkit-box-shadow: rgba(0, 0, 0, .25) 0 1px 0px;
				-moz-box-shadow: rgba(0, 0, 0, .25) 0 1px 0px;
				box-shadow: rgba(0, 0, 0, .25) 0 1px 0px;
			}
			
			button#bigbutton
			{
				width:300px;
				background: #3e9cbf; /*the colour of the button*/
				padding: 8px 14px 10px; /*apply some padding inside the button*/
				border:1px solid #3e9cbf; /*required or the default border for the browser will appear*/
				cursor:pointer; /*forces the cursor to change to a hand when the button is hovered*/
				//float:left;
				/*style the text*/
				font-size:1.5em;
				font-family:Oswald, sans-serif; /*Oswald is available from http://www.google.com/webfonts/specimen/Oswald*/
				letter-spacing:.1em;
				text-shadow: 0 -1px 0px rgba(0, 0, 0, 0.3); /*give the text a shadow - doesn't appear in Opera 12.02 or earlier*/
				color: #fff;
				
				/*use box-shadow to give the button some depth - see cssdemos.tupence.co.uk/box-shadow.htm#demo7 for more info on this technique*/
				-webkit-box-shadow: inset 0px 1px 0px #3e9cbf, 0px 5px 0px 0px #205c73, 0px 10px 5px #999;
				-moz-box-shadow: inset 0px 1px 0px #3e9cbf, 0px 5px 0px 0px #205c73, 0px 10px 5px #999;
				box-shadow: inset 0px 1px 0px #3e9cbf, 0px 5px 0px 0px #205c73, 0px 10px 5px #999;
				
				/*give the corners a small curve*/
				-moz-border-radius: 10px;
				-webkit-border-radius: 10px;
				border-radius: 10px;
			}

			
			
			button#bigbut
			{
				width:300px;
				background: #3e9cbf; /*the colour of the button*/
				padding: 8px 14px 10px; /*apply some padding inside the button*/
				border:1px solid #3e9cbf; /*required or the default border for the browser will appear*/
				cursor:pointer; /*forces the cursor to change to a hand when the button is hovered*/
				//float:right;
				/*style the text*/
				font-size:1.5em;
				font-family:Oswald, sans-serif; /*Oswald is available from http://www.google.com/webfonts/specimen/Oswald*/
				letter-spacing:.1em;
				text-shadow: 0 -1px 0px rgba(0, 0, 0, 0.3); /*give the text a shadow - doesn't appear in Opera 12.02 or earlier*/
				color: #fff;
				
				/*use box-shadow to give the button some depth - see cssdemos.tupence.co.uk/box-shadow.htm#demo7 for more info on this technique*/
				-webkit-box-shadow: inset 0px 1px 0px #3e9cbf, 0px 5px 0px 0px #205c73, 0px 10px 5px #999;
				-moz-box-shadow: inset 0px 1px 0px #3e9cbf, 0px 5px 0px 0px #205c73, 0px 10px 5px #999;
				box-shadow: inset 0px 1px 0px #3e9cbf, 0px 5px 0px 0px #205c73, 0px 10px 5px #999;
				
				/*give the corners a small curve*/
				-moz-border-radius: 10px;
				-webkit-border-radius: 10px;
				border-radius: 10px;
			}


			#my{
				//background-color: #d0d0d0;
				background-image:url(./img/hara.jpg);
				width: 80%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 25px;
				box-shadow:inset 0px 0px 15px 3px #707070;
			}

			#mya{
				//background-color: #d0d0d0;
				background-image:url(./img/hara.jpg);
				width: 80%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 10px;
				box-shadow:inset 0px 0px 15px 3px #707070;
			}


			#head{
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				width: 100%;
				margin-left: 0%;
				margin-right: 0%
				//background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				//-moz-border-radius:17px;
				//-webkit-border-radius:17px;
				//border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				//cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				//padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;
				//margin-left: auto;
				//margin-right: auto;


			}

		

			.tqf {
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				-moz-border-radius:17px;
				-webkit-border-radius:17px;
				border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;

			}
				.tqf:hover {
					background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #8cbf70), color-stop(1, #2a6139));
					background:-moz-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-webkit-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-o-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-ms-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:linear-gradient(to bottom, #8cbf70 5%, #2a6139 100%);
					filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#8cbf70', endColorstr='#2a6139',GradientType=0);
					background-color:#8cbf70;
				}
				.tqf:active {
					position:relative;
					top:1px;
				}



				.mcqf {
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				-moz-border-radius:17px;
				-webkit-border-radius:17px;
				border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;

			}
				.mcqf:hover {
					background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #8cbf70), color-stop(1, #2a6139));
					background:-moz-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-webkit-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-o-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-ms-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:linear-gradient(to bottom, #8cbf70 5%, #2a6139 100%);
					filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#8cbf70', endColorstr='#2a6139',GradientType=0);
					background-color:#8cbf70;
				}
				.mcqf:active {
					position:relative;
					top:1px;
				}

			#jinni
			{

				text-align: center;
				font-size: 20px;
			}
	 </style>
</head>
	<body bgcolor="BLACK">
		<div id="out">
			
			<div id="in">

				<div id="head">
							
						<h4 align="center"><font face="courier" size="7	">TEST IT</font></h4>	
						<!--<h2 align="center"> Universal Knowledge Center presents<br> TEST IT</h2>
						<h4 align="center"><p align="right">powered by BITW</p></h4>-->
				</div>


				

				<br /><br /><br /><br />


				<div align="center" id="mya">
					<font face="tamoha" size="5">
						<h6><font face="tamoha" size="4">Select Category of</font></h6>
						<h6><font face="tamoha" size="4">questions From BELOW!!</font></h6>
					</font>
				</div>
				
				<br /><br /><br />
				

				<div id="my" style="width:85%;margin-left:auto;margin-right:auto;text-align:center;"><!--This is just to select the type of questions		-->
					<p style="color:#061;"><?php echo $msg; ?></p>
					<!--<h3>Number of Questions??</h3>
					<form action="home.php" method="POST">
					<input type="text" id="noq" name="noq" placeholder="Type Number" />&nbsp;
					<input type="submit" name="number" value="Go Onn!" /><br />
					</form> 
					<?php
						//if(isset($_POST["number"] ))
						//{
						//echo "Number of Questions : ".$numb;
						//}
						//else
						//$numb="";
					?><br /><br /><br /><br />
					<br />

					<div id="jinni">
						<h6><font face="tamoha" size="5">Select Category of</font></h6>
						<h6><font face="tamoha" size="5">questions From BELOW!!</font></h6>
					</div>-->
					
					
					<br /><br />
					
					<button type="button" class="tqf" onClick="window.location='questqtf.php'">True/False</button>&nbsp;&nbsp;<br />
					<br />
					<br /><br />

					<button type="button" class="mcqf" onClick="window.location='questqmc.php'">MCQ</button>&nbsp;&nbsp;
					<!--<span id="resetBtn"><button onclick="resetQuiz()">Reset quiz to zero</button></span>-->
					<br /><br /><br />
						<div>
							<?php
								echo "Hello ".$username;
								echo " Click Here To  <a href='logout.php'> LogOut!</a>";
							?>
						</div>
						<br />
				</div>
			

<!--
			<div class="content" id="tf">This Div Contains True False Type Questions  
				<h3>True or false</h3>
					<form action="quest.php" name="addQuestion" method="post">
						<?php
						//for($i=0;$i<$numb;$i++)
						//{
						/*
							echo '	
								<input type="text" name="code" placeholder="Quiz CODE" /><br />
								<strong>Please type your new question here</strong><br />
								<textarea id="tfDesc" name="desc" style="width:95%;height:100px;"></textarea><br /><br />
								
								
								
								<strong>Please select whether true or false is the correct answer</strong>
								<br />
								<input type="text" id="answer1" name="answer1" value="True" readonly>&nbsp;
								<label style="cursor:pointer; color:#06F;">
									<input type="radio" name="iscorrect" value="answer1">Correct Answer?
								</label>
								<br /><br />
								<input type="text" id="answer2" name="answer2" value="False" readonly>&nbsp;
								<label style="cursor:pointer; color:#06F;">
									<input type="radio" name="iscorrect" value="answer2">Correct Answer?
								</label><br /><br />
								<input type="hidden" value="tf" name="type">
								<input id="submitbutton" type="submit" value="Add To Quiz">' ;
						//}
								*/
						?>
					</form>
			</div>
		
		<div class="content" id="mc">
			<h3>Multiple Choice</h3>
			<form action="quest.php" name="addMcQuestion" method="post">
				
				<?php
					//for($i=0;$i<$numb;$i++)
					//{
					/*


						echo '

						<input type="text" name="code" placeholder="Quiz CODE" /><br />
								

						
						<strong>Please type your new question here</strong>
						<br />
						<textarea id="mcdesc" name="desc" style="width:95%;height:100px;"></textarea>
						<br /><br />
						<strong>Please create the first answer for the question</strong>
						<br />
						<input type="text" id="mcanswer1" name="answer1">&nbsp;
						<label style="cursor:pointer; color:#06F;">
							<input type="radio" name="iscorrect" value="answer1">Correct Answer?
						</label>
						<br /><br />
						<strong>Please create the second answer for the question</strong>
						<br />
						<input type="text" id="mcanswer2" name="answer2">&nbsp;
						<label style="cursor:pointer; color:#06F;">
							<input type="radio" name="iscorrect" value="answer2">Correct Answer?
						</label><br /><br />
						<strong>Please create the third answer for the question</strong>
						<br />
						<input type="text" id="mcanswer3" name="answer3">&nbsp;
						<label style="cursor:pointer; color:#06F;">
							<input type="radio" name="iscorrect" value="answer3">Correct Answer?
						</label>
						<br /><br />
						<strong>Please create the fourth answer for the question</strong>
						<br />
						<input type="text" id="mcanswer4" name="answer4">&nbsp;
						<label style="cursor:pointer; color:#06F;">
							<input type="radio" name="iscorrect" value="answer4">Correct Answer?
						</label>
						<br /><br />
						<input type="hidden" value="mc" name="type">
						<input id="submitbutton" type="submit" value="Add To Quiz">';
					
					//}
						*/
				?>
			</form>
		</div>-->
		</div>
		</div>
	</body>
</html>