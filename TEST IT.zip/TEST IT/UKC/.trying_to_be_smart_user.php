<?php
	echo "You have already Attempted the quiz once.....FUCKER !! MOTHER FUCKER !! (in a low tone from the throat.SILENTLY)";
?>