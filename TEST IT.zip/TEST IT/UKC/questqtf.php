<?php
	include("session.php");
?>




<?php
	if(isset($_POST['desc']))
	{
		if(!isset($_POST['iscorrect']) || $_POST['iscorrect'] == "")
		{
			echo '<div id="msg_pst">
						  <p class="msps"> <h1 align="center"><font face="courier" size="3" color="red">Sorry, important data to submit your question is missing. Please press home and try again and make sure you select a correct answer for the question.</font></h1></p>
				</div>';
			//echo "Sorry, important data to submit your question is missing. Please press back in your browser and try again and make sure you select a correct answer for the question.";
			//exit();
		}
		if(!isset($_POST['type']) || $_POST['type'] == "")
		{
			echo '<div id="msg_pst">
						  <p class="msps"> <h1 align="center"><font face="courier" size="3" color="red">Sorry, there was an error parsing the form. Please press home and try again.</font></h1></p>
				</div>';
			//echo "Sorry, there was an error parsing the form. Please press back in your browser and try again";
			//exit();
		}
		$question = $_POST['desc'];
		$answer1 = $_POST['answer1'];
		$answer2 = $_POST['answer2'];
		$answer3 = $_POST['answer3'];
		$answer4 = $_POST['answer4'];
		$type = $_POST['type'];
		$code = $_POST['code'];
		$type = preg_replace('/[^a-z]/', "", $type);
		$isCorrect = preg_replace('/[^0-9a-z]/', "", $_POST['iscorrect']);
		$answer1 = strip_tags($answer1);
		$answer1 = mysql_real_escape_string($answer1);
		$answer2 = strip_tags($answer2);
		$answer2 = mysql_real_escape_string($answer2);
		$answer3 = strip_tags($answer3);
		$answer3 = mysql_real_escape_string($answer3);
		$answer4 = strip_tags($answer4);
		$answer4 = mysql_real_escape_string($answer4);
		$question = strip_tags($question);
		$question = mysql_real_escape_string($question);
		if($type == 'tf')
		{
			if((!$question) || (!$answer1) || (!$answer2) || (!$isCorrect))
			{
				echo '<div id="msg_pst">
						  <p class="msps"> <h1 align="center"><font face="courier" size="3" color="red">Sorry, All fields must be filled in to add a new question to the quiz. Please press back in your browser and try again.</font></h1></p>
				</div>';
				//echo "Sorry, All fields must be filled in to add a new question to the quiz. Please press back in your browser and try again.";
				//exit();
			}
		}
		if($type == 'mc')
		{
			if((!$question) || (!$answer1) || (!$answer2) || (!$answer3) || (!$answer4) || (!$isCorrect))
			{
				echo '<div id="msg_pst">
						  <p class="msps"> <h1 align="center"><font face="courier" size="3" color="red">Sorry, All fields must be filled in to add a new question to the quiz. Please press back in your browser and try again.</font></h1></p>
				</div>';
				//echo "Sorry, All fields must be filled in to add a new question to the quiz. Please press back in your browser and try again.";
				//exit();
			}
		}
		$sql = mysql_query("INSERT INTO questions (question, type,code,username) VALUES ('$question', '$type', '$code', '$username')")or die(mysql_error());
		$lastId = mysql_insert_id();
		mysql_query("UPDATE questions SET question_id='$lastId' WHERE id='$lastId' LIMIT 1")or die(mysql_error());
		//// Update answers based on which is correct //////////
		if($type == 'tf')
		{
			if($isCorrect == "answer1")
			{
				$sql2 = mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer1', '1')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer2', '0')")or die(mysql_error());
				$msg = 'Thanks, your question has been added';
				$answer3="";
				header('location: quest.php?msg='.$msg.'');
				exit();
			}
			if($isCorrect == "answer2")
			{
				$sql2 = mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer1', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer2', '1')")or die(mysql_error());
				$msg = 'Thanks, your question has been added';
				header('location: quest.php?msg='.$msg.'');
				exit();
			}	
		}
		if($type == 'mc')
		{
			if($isCorrect == "answer1")
			{
				$sql2 = mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer1', '1')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer2', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer3', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer4', '0')")or die(mysql_error());
				$msg = 'Thanks, your question has been added';
				header('location: quest.php?msg='.$msg.'');
				exit();
			}
			if($isCorrect == "answer2")
			{
				$sql2 = mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer1', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer2', '1')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer3', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer4', '0')")or die(mysql_error());
				$msg = 'Thanks, your question has been added';
				header('location: quest.php?msg='.$msg.'');
				exit();
			}
			if($isCorrect == "answer3")
			{
				$sql2 = mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer1', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer2', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer3', '1')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer4', '0')")or die(mysql_error());
				$msg = 'Thanks, your question has been added';
				header('location: quest.php?msg='.$msg.'');
				exit();
			}
			if($isCorrect == "answer4")
			{
				$sql2 = mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer1', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer2', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer3', '0')")or die(mysql_error());
				mysql_query("INSERT INTO answers (question_id, answer, correct) VALUES ('$lastId', '$answer4', '1')")or die(mysql_error());
				$msg = 'Thanks, your question has been added';
				header('location: quest.php?msg='.$msg.'');
				exit();
			}
		}
	}
?>

<?php 
	$msg = "";
	if(isset($_GET['msg']))
	{
		$msg = $_GET['msg'];
	}
?>
<?php 
	if(isset($_POST['reset']) && $_POST['reset'] != "")
	{
		$reset = preg_replace('/^[a-z]/', "", $_POST['reset']);
		mysql_query("TRUNCATE TABLE questions")or die(mysql_error());
		mysql_query("TRUNCATE TABLE answers")or die(mysql_error());
		$sql1 = mysql_query("SELECT id FROM questions LIMIT 1")or die(mysql_error());
		$sql2 = mysql_query("SELECT id FROM answers LIMIT 1")or die(mysql_error());
		$numQuestions = mysql_num_rows($sql1);
		$numAnswers = mysql_num_rows($sql2);
		if($numQuestions > 0 || $numAnswers > 0)
		{
			echo "Sorry, there was a problem reseting the quiz. Please try again later.";
			exit();
		}
		else
		{
			echo "Thanks! The quiz has now been reset back to 0 questions.";
			exit();
		}
	}
	
	//reading N
	
	//$number=@$_POST['number'];
	if(isset($_POST["number"] ))
	{
		$numb=@$_POST['noq'];
		//echo "number=".$numb;
	}
	
?>

<html>
	<head>
		<script>
			function showDiv(el1,el2)
			{
				document.getElementById(el1).style.display = 'block';
				document.getElementById(el2).style.display = 'none';
			}
		</script>

		<style type="text/css">
		*
			{
				margin:0;
			}

			#out
			{
				//margin:0;
				//padding:2%;
				//border:solid black;
				background-image:url(./img/g8.jpg);
				//background-color:black;
			}

			#in
			{
				//border:solid black;
				width:98%;
				//margin:0;
				height:100%;
				margin-left:auto;
				margin-right:auto;
				//margin-top:-49%;
				background-color:white;
				background-image:url(./img/g8.jpg);
				//border-radius:25%;
			}

			#my{
				//background-color: #d0d0d0;
				background-image:url(./img/hara.jpg);
				width: 95%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 25px;
				box-shadow:inset 0px 0px 15px 3px #707070;
			}

			#mya{
				//background-color: #d0d0d0;
				background-image:url(./img/hara.jpg);
				width: 40%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 10px;
				box-shadow:inset 0px 0px 15px 3px #707070;
			}

			input[type="text"]
			{
				height:1%;
				width:40%;
				margin-left:0%;
				//margin-right:auto;
				margin-top:3%;
				
				padding: 10px;
				//border: solid 1px #fff;
				//box-shadow: inset 5px 5px 7px 0 #707070;
				//transition: box-shadow 0.3s;
			}

			#head
			{
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				width: 100%;
				margin-left: 0%;
				margin-right: 0%
				//background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				//-moz-border-radius:17px;
				//-webkit-border-radius:17px;
				//border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				//cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				//padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;
				//margin-left: auto;
				//margin-right: auto;
			}

			.takequiz {
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				-moz-border-radius:17px;
				-webkit-border-radius:17px;
				border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;

			}
				.takequiz:hover {
					background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #8cbf70), color-stop(1, #2a6139));
					background:-moz-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-webkit-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-o-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-ms-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:linear-gradient(to bottom, #8cbf70 5%, #2a6139 100%);
					filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#8cbf70', endColorstr='#2a6139',GradientType=0);
					background-color:#8cbf70;
				}
				.takequiz:active {
					position:relative;
					top:1px;
				}

		</style>
	</head>
	<body>
		<div id="out">
			<div id="in">
				<div id="head">
					
					<h4 align="center"><font face="courier" size="7">TEST IT</font></h4>
					<!--<h2 align="center"> Universal Knowledge Center presents<br> TEST IT</h2>
					<h4 align="center"><p align="right">powered by BITW</p></h4>-->
					
				</div>

				<br /><br /><br />

				<div align="center" id="mya">
					<font face="tamoha" size="3">
						<h3>True/false</h3>
					</font>
				</div>

				<br /><br />

				<div id="my" align="center"><!--This Div Contains True False Type Questions  -->

					<br />	
					<form action="quest.php" name="addQuestion" method="post">
						<?php
						//for($i=0;$i<$numb;$i++)<br /><br />
						//{
							echo '	
								<strong>Assign quiz code:</strong>
								<input type="text" name="code" placeholder="Quiz CODE" /><br /><br />
								<strong>Please type your new question below:</strong><br />
								<textarea id="tfDesc" name="desc" style="width:95%;height:100px;"></textarea><br /><br />
								
								
								
								<strong>Please select whether true or false:</strong>
								<br />
								<input type="text" id="answer1" name="answer1" value="True" readonly>&nbsp;
								<label style="cursor:pointer; color:#061;">
									<input type="radio" name="iscorrect" value="answer1">Correct Answer?
								</label>
								
								<input type="text" id="answer2" name="answer2" value="False" readonly>&nbsp;
								<label style="cursor:pointer; color:#061;">
									<input type="radio" name="iscorrect" value="answer2">Correct Answer?
								</label><br /><br />
								<input type="hidden" value="tf" name="type">
								<input id="submitbutton" class="takequiz" type="submit" value="Add To Quiz">' ;
						//}
						?>
					</form>
					<br />
				</div>
			</div>
		</div>	
	</body>
</html>
