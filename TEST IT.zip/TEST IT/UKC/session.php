<?php 
	include("connect_to_db.php");
	$abc="i am BITW";
	session_start();
	if (!isset($_SESSION['uname']))
	{
		//echo "not set";
		$username="";
	}
	else
	{
		//echo 'in head_index'.$_SESSION['uname'];
		$username = $_SESSION['uname'];
		//include 'head_menu.php';
		$adm_na="";
		
	}
	
	if (!isset($_SESSION['aname']))
	{
		//echo "not set";
		$adm_na="";
	}
	else
	{
		//echo 'in head_index'.$_SESSION['uname'];
		$adm_na = $_SESSION['aname'];
		//include 'head_menu.php';
	
	}
	
?>