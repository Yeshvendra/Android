<?php
include("session.php");
?>

<?php
	$code="";
	$no_of_qstns=0;
	$flag=0;
	$trying_to_be_smart= $_SESSION['uname'];
	$trying_code="";
	if(isset ($_POST["code"]) )
	{
		$trying_code=$_POST['code'];
		$check1=mysql_query("SELECT COUNT(*) FROM quiz_takers",$conn);
		$check2=mysql_fetch_array($check1);
		$check3=$check2[0];
		$check4=mysql_query("SELECT username,code FROM quiz_takers", $conn);
		for($i=0;$i<$check3;$i++)
		{
			$check5=mysql_fetch_array($check4);
			$check_name=$check5['username'];
			$check_code=$check5['code'];
			if(($check_name==$trying_to_be_smart) && ($check_code==$trying_code))
			{
				$flag=1;
				//header("location: trying_to_be_smart_user.php");
				//echo "Don't try to be oversmart !! You have been caught cheating !!";
				echo '<div id="msg_pst">
						  <p class="msps"> <h1 align="center"><font face="courier" size="3" color="red">Dont try to be oversmart !! You have been caught cheating !!</font></h1></p>
				</div>';
			}
		}
		if($flag==0)
		{

			$sql = mysql_query("SELECT id FROM questions WHERE code='".$_POST['code']."' ",$conn);
			
			$userCount = mysql_num_rows($sql); //
			if ($userCount >=1)
			{
				if($row = mysql_fetch_array($sql))
				{ 
					$id = $row["id"];
				}
				
				$_SESSION["code"] = $_POST['code'];
				echo $_SESSION['code'];
				$query=mysql_query("SELECT COUNT(*) FROM questions");
				$row=mysql_fetch_array($query);
				$rows=$row[0];
				$query1=mysql_query("select question_id,question,type,code from questions");
				for($i=0; $i<$rows ; $i++)
				{
					$ans=mysql_fetch_array($query1);
					$name=$ans['code'];
					if($name == $_SESSION['code'])
					{
						$no_of_qstns+=1;
					}
				}
				$_SESSION["no_of_qstns"] = $no_of_qstns;
				header("location: test.php");
				exit();
			}
			else
			{
				echo '<div id="msg_pst">
						  <p class="msps"> <h4 align="center"><font face="courier" size="3" color="red">Invalid Quiz Code....Try Again Later !!</font></h4></p>
				</div>';
				//exit();
			}
		}	
	}
?>

<html>
	<head>
		<script>
			function showDiv(el1,el2)
			{
				document.getElementById(el1).style.display = 'block';
				document.getElementById(el2).style.display = 'none';
			}
		</script>

		<style type="text/css">
		*
			{
				margin:0;
			}

			#out
			{
				//margin:0;
				//padding:2%;
				//border:solid black;
				background-image:url(./img/g8.jpg);
				//background-color:black;
			}

			#in
			{
				//border:solid black;
				width:100%;
				//margin:0;
				height:100%;
				margin-top: auto;
				margin-bottom: auto;
				margin-left:auto;
				margin-right:auto;
				//margin-top:-49%;
				background-color:white;
				background-image:url(./img/g8.jpg);
				//border-radius:25%;
			}

			#my{
				//background-color: #d0d0d0;
				background-image:url(./img/hara.jpg);
				width: 80%;
				margin-top: auto;
				margin-bottom: auto;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 25px;
				box-shadow:inset 0px 0px 15px 3px #707070;
			}

			#mya{
				//background-color: #d0d0d0;
				background-image:url(./img/hara.jpg);
				width: 40%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 10px;
				box-shadow:inset 0px 0px 15px 3px #707070;
			}

			input[type="text"]
			{
				height:6%;
				width:50%;
				margin-top:auto;
				margin-left:0%;
				//margin-right:auto;
				margin-top:3%;
				
				padding: 10px;
				border: solid 1px #fff;
				box-shadow: inset 5px 5px 7px 0 #707070;
				transition: box-shadow 0.3s;
			}

			#head
			{
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				width: 98%;
				margin-left: 1%;
				//margin-right: 0%
				//background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				//-moz-border-radius:17px;
				//-webkit-border-radius:17px;
				//border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				//cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				//padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;
				//margin-left: auto;
				//margin-right: auto;
			}

			.takequiz {
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				-moz-border-radius:17px;
				-webkit-border-radius:17px;
				border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;

			}
				.takequiz:hover {
					background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #8cbf70), color-stop(1, #2a6139));
					background:-moz-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-webkit-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-o-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-ms-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:linear-gradient(to bottom, #8cbf70 5%, #2a6139 100%);
					filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#8cbf70', endColorstr='#2a6139',GradientType=0);
					background-color:#8cbf70;
				}
				.takequiz:active {
					position:relative;
					top:1px;
				}

		</style>
	</head>
	
	<body>
		<div id="out">
			<div id="in">		

				<div id="head">
							
					<h4 align="center"><font face="courier" size="7">TEST IT</font></h4>
					<!--<h2 align="center"> Universal Knowledge Center presents<br> TEST IT</h2>
					<h4 align="center"><p align="right">powered by BITW</p></h4><br />-->
							
				</div>
				<br /><br /><br /><br />

				<div align="center" id="mya">
					<font face="tamoha" size="5">
						<?php
							echo "Hello ".$username;
						?>
					</font>
				</div>


				<br /><br /><br /><br /><br /><br /><br />
				<div align="center" id="my">
					<form action="quizcode.php" method="POST">
						
						<br />
						<input type="text" name="code" placeholder="Quiz CODE" /><br />
						<br />
						<input id="submitbutton" class="takequiz" type="submit" value="Start Quiz"><br />
						<br />
					</form>

					<?php
						echo " Click Here To .... <a href='logout.php'> LogOut!</a>";
					?>
					<br />
					<br />
				</div>		
			</div>
		</div>
	</body>
</html>