<?php
	$conn=mysql_connect("localhost","root","") or die("could not connect to localhost");
	
	mysql_select_db("quiz") or die("could not connect to login details");
?>