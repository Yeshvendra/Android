<?php
	include("connect_to_db.php");
?>

<?php
			$un="";
			$fn="";
			$ln="";
			$ps="";
			$rps="";
			$st="";
			$ct="";
			$sta="";
			$re="";
			$co="";
			$pi="";
			$mob="";
			$check="";
			$u_check="";
			$signup=@$_POST['signup'];
			$un=strip_tags(@$_POST['uname']);
			$fn=strip_tags(@$_POST['fname']);
			$ln=strip_tags(@$_POST['lname']);
			$ps=strip_tags(@$_POST['paswd']);
			$rps=strip_tags(@$_POST['repaswd']);
			$st=strip_tags(@$_POST['street']);
			$ct=strip_tags(@$_POST['city']);
			$sta=strip_tags(@$_POST['state']);
			$re=strip_tags(@$_POST['region']);
			$co=strip_tags(@$_POST['country']);
			$pi=strip_tags(@$_POST['pincode']);
			$mob=strip_tags(@$_POST['mob']);
			if (isset($signup))
			{
				$u_check = mysql_query("SELECT uid FROM users WHERE uid='$un'");
				$check = mysql_num_rows($u_check);
				//echo "1";
				if ($check == 0)
				{
					if ($fn&&$ln&&$un&&$ps&&$rps&&$st&&$ct&&$sta&&$re&&$co&&$pi)
					{
						if ($ps==$rps)
						{
							if (strlen($pi)!=6||strlen($mob)!=10) 
							{
								echo "Incorrect PINCODE! or Mobile Number";
							}
							else{
							if (strlen($un)>20||strlen($fn)>20||strlen($ln)>20||strlen($st)>20||strlen($ct)>20||strlen($sta)>20||strlen($re)>20||strlen($co)>20)
							{
								echo "The maximum limit for username/first name/last name/street/city/region/country is 20 characters!";
							}
							else
							{
								if (strlen($ps)>20||strlen($ps)<5)
								{
									echo "Your password must be between 5 and 20 characters long!";
								}
								else
								{
									$query = mysql_query("INSERT INTO users VALUES ('','$un','$ps','$fn','$ln','$st','$ct','$sta','$re','$co','$pi','$mob')",$conn);
									header("location:home.php");
								}
							}
						}}
						else
						{
							echo "Your passwords don't match!";
						}
					}
					else
					{
						echo "Please fill in all of the fields";
					}
				}
				else
				{
					echo "Username already taken ...";
				}
			}
		?>
<html>
	<head>
		<script>
			function showDiv(el1,el2)
			{
				document.getElementById(el1).style.display = 'block';
				document.getElementById(el2).style.display = 'none';
			}
		</script>

		<style type="text/css">
		*
			{
				margin:0;
			}

			#out
			{
				//margin:0;
				//padding:2%;
				//border:solid black;
				height:auto;
				background-image:url(./bkg1.jpg);
				//background-color:black;
				//overflow: scroll;
			}

			#in
			{
				//border:solid black;
				width:100%;
				//margin:0;
				height:auto;
				margin-left:auto;
				margin-right:auto;
				//margin-top:-49%;
				background-color:white;
				//background-image:url(./bkg1.jpg);
				//border-radius:25%;
			}

			#my{
				//background-color: #d0d0d0;
				background-image:url(./bkg1.jpg);
				width: 100%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 25px;
				box-shadow:inset 0px 0px 15px 3px #707070;
			}

			#mya{
				//background-color: #d0d0d0;
				background-image:url(./hara.jpg);
				width: 70%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 10px;
				//box-shadow:inset 0px 0px 15px 3px #707070;			
			}

			input[type="text"]
			{
				height:8%;
				width:80%;
				margin-left:10%;
				//margin-right:auto;
				margin-top:3%;				
				padding: 10px;
				border: solid 1px #fff;
				box-shadow: inset 3px 3px 5px 0 #707070;
				transition: box-shadow 0.3s;
			}

			input[type="password"]
			{
				height:8%;
				width:80%;
				margin-left:10%;
				//margin-right:auto;
				margin-top:3%;
				
				padding: 10px;
				border: solid 1px #fff;
				box-shadow: inset 3px 3px 5px 0 #707070;
				transition: box-shadow 0.3s;
			}

			input[type="submit"]
			{
				height:auto;
				width:80%;
				/*margin-left:25%;
				
				color: #fff;
				background-color: #0f0f0f;
				border: none;
				border-radius: 5px;
				//box-shadow: 0 10px #95a484;*/
			}
			#head
			{
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				width: 98%;
				margin-left: 1%;
				margin-right: 0%
				//background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				//-moz-border-radius:17px;
				//-webkit-border-radius:17px;
				//border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				//cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				//padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;
				//margin-left: auto;
				//margin-right: auto;
			}

			.myButton {
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				-moz-border-radius:17px;
				-webkit-border-radius:17px;
				border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;

			}
				.myButton:hover {
					background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #8cbf70), color-stop(1, #2a6139));
					background:-moz-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-webkit-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-o-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:-ms-linear-gradient(top, #8cbf70 5%, #2a6139 100%);
					background:linear-gradient(to bottom, #8cbf70 5%, #2a6139 100%);
					filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#8cbf70', endColorstr='#2a6139',GradientType=0);
					background-color:#8cbf70;
				}
				.myButton:active {
					position:relative;
					top:1px;
				}

		</style>
	</head>
	<body>
	<div id="out">
		<div id="signin">
			<div id="out">
			<div id="head">
				<h4 align="center"><font face="courier" type="form" size="7">ePOST</font></h4>
			</div>
			<br><br><br><br>
			<div id="mya">
				<br />
				<center>
					<form action="sign_up.php" method="POST">
						<table>
						<tr>
							<th>Username :</th> <th><input type="text" name="uname" placeholder="USERNAME" /></th>
						</tr>
						<tr>
							<th>First Name : </th><th><input type="text" name="fname" placeholder="FIRSTNAME" /></th>
						</tr>
						<tr>
							<th>Last Name : </th><th><input type="text" name="lname" placeholder="LASTNAME" /></th>
						</tr>
						<tr>
							<th>Password : </th><th><input type="password" name="paswd" placeholder="PASSWORD" /></th>
						</tr>
						<tr>
							<th>Re-enter Password : </th><th><input type="password" name="repaswd" placeholder="PASSWORD" /></th>
						</tr>
						<tr>
							<th>Street : </th><th><input type="text" name="street" placeholder="STREET" /></th>
						</tr>
						<tr>
							<th>City : </th><th><input type="text" name="city" placeholder="CITY" /></th>
						</tr>
						<tr>
							<th>State : </th><th><input type="text" name="state" placeholder="STATE" /></th>
						</tr>
						<tr>
							<th>Region : </th><th><input type="text" name="region" placeholder="REGION" /></th>
						</tr>
						<tr>
							<th>Country : </th><th><input type="text" name="country" placeholder="COUNTRY" /></th>
						</tr>
						<tr>
							<th>Pincode : </th><th><input type="text" name="pincode" placeholder="PINCODE" /></th>
						</tr>
						<tr>
							<th>Mobile Number : </th><th><input type="text" name="mob" placeholder="MOBILE NUMBER" /></th>
						</tr>
						<tr>
							<th><br><input type="submit" class="myButton" name="signup" value="Sign Up!" align="right" /></th>
						</tr>
						</table>
					</form>
				</center>
				<br><br>
				</div>
				<br>
			</div>
			<br>
		</div>
	</div>
	</body>
</html>