<?php
	$conn=mysql_connect("localhost","root","") or die("could not connect to localhost");
	
	mysql_select_db("post_office") or die("could not connect to login details");
?>