<?php
	
	include("session.php");
	
?>
<html>
<head>
	<style type="text/css">
			*
			{
				margin:0;
			}
			#out
			{
				//margin:0;
				//padding:2%;
				//border:solid black;
				background-color:black;
				height:100%;
				overflow: scroll;
				background-image:url(./bkg1.jpg);
			}
			#in
			{
				//border:solid black;
				width:98%;
				height:93.5%;
				margin-left:auto;
				margin-right:auto;
				//background-color:white;
				
				//border-radius:25%;
				color:white;
				font-size:200%;
			}
			#mya{
				//background-color: #d0d0d0;
				background-image:url(./hara.jpg);
				width: 70%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 10px;
				//box-shadow:inset 0px 0px 15px 3px #707070;			
			}
			#head
			{
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				width: 98%;
				margin-left: 1%;
				margin-right: 0%
				//background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				//-moz-border-radius:17px;
				//-webkit-border-radius:17px;
				//border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				//cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				//padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;
				//margin-left: auto;
				//margin-right: auto;
			}
	</style>
</head>
<body>
<div id="out">
	<div id="head">
				<h4 align="center"><font face="courier" type="form" size="7">ePOST</font></h4>
			</div>
			<br><br>
		<div id="mya" align="center">
		<br>	
		<?php 
							echo "<h3>Hello $username<br></h3>";
							echo " Click Here To Log Out... <a href='logout.php'> LogOut!</a><br>";
		?>
		<br />
		</div>
		<br><br><br><br><br><br><br><br>
		<div id="mya" align="center">
		<br>
		<br /><b><font face="courier" color="Red" size="5">You Have Successfully send the POST.</font></b><br />
		<br />
		</div>
</div>
</body>
</html>