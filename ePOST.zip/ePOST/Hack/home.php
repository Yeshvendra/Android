<?php
	
	include("session.php");
	
	
	$msg = "";
	if(isset($_GET['msg']))
	{
		$msg = $_GET['msg'];
		$msg = strip_tags($msg);
		$msg = addslashes($msg);
	}
?>

<html>
	<head>
		<style type="text/css">
			*
			{
				margin:0;
			}
			#out
			{
				//margin:0;
				//padding:2%;
				//border:solid black;
				background-color:black;
				height:100%;
				overflow: scroll;
				background-image:url(./bkg1.jpg);
			}
			#in
			{
				//border:solid black;
				width:98%;
				height:93.5%;
				margin-left:auto;
				margin-right:auto;
				//background-color:white;
				
				//border-radius:25%;
				color:white;
				font-size:200%;
			}
			#mya{
				//background-color: #d0d0d0;
				background-image:url(./hara.jpg);
				width: 70%;
				margin-left: auto;
				margin-right: auto;
				//border: solid 1px #000000;
				border-radius: 10px;
				//box-shadow:inset 0px 0px 15px 3px #707070;			
			}
			#head
			{
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				width: 98%;
				margin-left: 1%;
				margin-right: 0%
				//background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#2a6139', endColorstr='#8cbf70',GradientType=0);
				background-color:#2a6139;
				//-moz-border-radius:17px;
				//-webkit-border-radius:17px;
				//border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				//cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				//padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;
				//margin-left: auto;
				//margin-right: auto;
			}
			.myButton
			{
				-moz-box-shadow:inset 0px 0px 15px 3px #4a803b;
				-webkit-box-shadow:inset 0px 0px 15px 3px #4a803b;
				background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2a6139), color-stop(1, #8cbf70));
				background:-moz-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-webkit-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-o-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:-ms-linear-gradient(top, #2a6139 5%, #8cbf70 100%);
				background:linear-gradient(to bottom, #2a6139 5%, #8cbf70 100%);
				box-shadow:inset 0px 0px 15px 3px #4a803b;
				background-color:#2a6139;
				-moz-border-radius:17px;
				-webkit-border-radius:17px;
				border-radius:17px;
				border:1px solid #182e1a;
				display:inline-block;
				cursor:pointer;
				color:#ffffff;
				font-family:Arial;
				font-size:15px;
				padding:6px 13px;
				text-decoration:none;
				text-shadow:0px 1px 0px #2f6627;
			}
			input[type="button"]
			{
				height:10%;
				width:50%;
				margin-left:25%;
				font-size:96%;
				color: #fff;
				background-color: #6496c8;
				border: none;
				border-radius: 15px;
				box-shadow: 0 10px #27496d;
			}
			#one
			{
				border:3px solid black;
				width:400px;
				height:auto;
				margin-left:auto;
				margin-right:auto;
			}			
		</style>
	</head>
	
	<body>
	<div id="out">
	<div id="head">
				<h4 align="center"><font face="courier" type="form" size="7">ePOST</font></h4>
			</div>
			<br><br>
		<div id="mya" align="center">
		<br>	
		<?php echo $msg; 
							echo "<h3>Hello $username<br></h3>";
							echo " Click Here To Log Out... <a href='logout.php'> LogOut!</a><br>";
		?>
		<br />
		</div>
		<br><br>
		<div id="mya" align="center">
		<form action="home.php" method="POST">
			<br /><b>Enter reciever's Mobile Number : </b><input type="text" name="mob" placeholder="10 Digit Mobile Number" /><br />
			<br /><input type="submit" class="myButton" name="sub" value="Submit" />
			<br><br>
			<?php
	
				$sub=@$_POST['sub'];
				$mob=strip_tags(@$_POST['mob']);
				$d=date("Y-m-d");
				if(isset($sub))
				{
					if(strlen ($mob) !=10)
						echo "Please enter a valid Mobile Number . ";
					else
					{
						$query=mysql_query("SELECT COUNT(*) FROM users");
						$row=mysql_fetch_array($query);
						$rows=$row[0];
						$query1=mysql_query("select uid,firstname,lastname,street,city,state,region,country,pincode,mobile_no from users");
						for($i=0; $i<$rows ; $i++)
						{
							$ans=mysql_fetch_array($query1);
							$mob_check=$ans['mobile_no'];
							if($mob_check == $mob)
							{
								$_SESSION['mob_sen']=$mob;
								$_SESSION['mob_rec']=$mob_check;
								$msg1=$ans['firstname'];
								$msg2=$ans['lastname'];
								$msg3=$ans['street'];
								$msg4=$ans['city'];
								$msg5=$ans['state'];
								$msg6=$ans['region'];
								$msg7=$ans['country'];
								$msg8=$ans['pincode'];
								echo "";
								echo '
										<div id="one">
										<br /> <b>Kindly Check the Recievers Address : </b><br /><br /><br />
										<table>
											<tr>
												<th>First Name : </th>
												<th>'.$msg1.'</th>
											</tr>
								
											<tr>
												<th>Last Name : </th>
												<th>'.$msg2.'</th>
											</tr>
								
											<tr>
												<th>Street : </th>
												<th>'.$msg3.'</th>
											</tr>
								
											<tr>
												<th>City : </th>
												<th>'.$msg4.'</th>
											</tr>
								
											<tr>
												<th>State : </th>
												<th>'.$msg5.'</th>
											</tr>
								
											<tr>
												<th>Region : </th>
												<th>'.$msg6.'</th>
											</tr>
								
											<tr>
												<th>Country : </th>
												<th>'.$msg7.'</th>
											</tr>
								
											<tr>
												<th>Pincode : </th>
												<th>'.$msg8.'</th>
											</tr>
								
											<tr>
												<th>Mobile Number : </th>
												<th>'.$mob_check.'</th>
											</tr>
											
											<tr>
												<th>
													<br /><input type="submit" class="myButton" name="sub_ad" value="Send To This Address" /><br><br />
												</th>
											</tr>
										</table>
										</div>
							';
						
				}
			}
			
			
		}
	}
	$sub12=@$_POST['sub_ad'];
			if(isset($sub12))
			{
				$mob=$_SESSION['mob_sen'];
				$mob_check=$_SESSION['mob_rec'];
				$query123 = mysql_query("INSERT INTO track VALUES ('','$mob','$mob_check','$d')",$conn);
				header("location:track.php");
			}
?>
		</form>
		<br>
		</div>
	</div>	
	</body>
</html>