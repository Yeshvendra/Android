package com.example.ePost;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.widget.VideoView;

public class Splash extends Activity implements OnCompletionListener
{
   //MediaPlayer ourSong;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);

        //ourSong = MediaPlayer.create(Splash.this , R.);

        //SharedPreferences getPrefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        //boolean music = getPrefs.getBoolean("checkbox", true);
        //if(music == true) {
        //    ourSong.start();
        //}

        Thread timer = new Thread(){
            public void run(){
                try{sleep(2500);}
                catch (InterruptedException e){e.printStackTrace();}
                finally {
                    Intent openBlank = new Intent("com.example.ePost.Webmini");
                    startActivity(openBlank);
                }

            }
        };
        timer.start();
    }

    @Override
    protected void onPause(){
        super.onPause();
        ourSong.release();
        finish();
    }
}